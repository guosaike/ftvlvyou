from fastapi.exceptions import HTTPException

from models import *

from fastapi import Request

# 这里是类似于 drf 的字段校验
from pydantic import BaseModel
from typing import List, Union
# 类似于django里的 path
from fastapi import APIRouter
# 生成路由对象
api_book = APIRouter()


# 查所有
@api_book.get("/")
async def getAllBook(request: Request):

    # 拿到前端传递的分页参数
    pageNum = int(request.query_params.get('pageNum', ''))
    pageSize = int(request.query_params.get('pageSize', ''))

    # 过滤
    search_nick_term = request.query_params.get('title', '')
    if search_nick_term:
        search_nick_term = search_nick_term.strip()
        books_sousuo = Book.filter(title__icontains=search_nick_term)
    else:
        # 拿到所有学生信息
        books_sousuo = Book.all()

    # 分页
    page_obj_zs = await books_sousuo.all().count()
    pianyi = (pageNum - 1) * pageSize  # 计算偏移量
    books = books_sousuo.limit(pageSize).offset(pianyi).order_by("id")

    books = await books.all().values("id","title","price","img_url","bread","bcomment","publishs__id","publishs__name","authors__id","authors__name")
    # books = await Book.filter(name__icontains='a').values("name", "clas__name")

    return {'code': 200, 'zs': page_obj_zs, 'data': books}


class BookModel(BaseModel):
    title: str
    price: int
    img_url: str
    bread: int
    clas_id: Union[int, None] = None
    authors: List[int] = []

# 增加
@api_book.post("/")
async def addBook(stu: BookModel,request: Request):
    # 添加数据库操作
    # 方式1
    # book = Book(name=stu.name, pwd=stu.pwd, sno=stu.sno, clas_id=stu.clas)
    # await book.save()
    # 方式2

    # 拿到前端传递的图书
    json_data = await request.json()
    title = json_data["title"]
    price = json_data["price"]
    bread = json_data["bread"]
    bcomment = json_data["bcomment"]
    img_url = json_data["img_url"]
    publishs_id = json_data["publishs_id"]
    authors_id = json_data["authors_id"]

    book = await Book.create(title=title,price=price,img_url=img_url,bread=bread,bcomment=bcomment,publishs_id=publishs_id)

    # 添加多对多关系记录
    author = await Author.filter(id__in=authors_id)
    await book.authors.add(*author)

    return {'code': 200, 'message': "增加成功", 'data': book}

# 查看一个
@api_book.get("/{book_id}")
async def update_book(book_id: int):
    book = await Book.get(id=book_id).values("id","sno","pwd","name","clas__id","clas__name","courses__id","courses__name")

    return book

# 修改一个
@api_book.put("/{book_id}")
async def update_book(book_id: int, book: BookModel,request: Request):
    # 拿到前端传递的图书
    json_data = await request.json()
    # data = book.dict(exclude_unset=True)
    # print(json_data)
    # courses = data.pop("authors")

    title = json_data["title"]
    price = json_data["price"]
    bread = json_data["bread"]
    bcomment = json_data["bcomment"]
    img_url = json_data["img_url"]
    publishs_id = json_data["publishs_id"]
    authors_id = json_data["authors_id"]

    await Book.filter(id=book_id).update(title=title,price=price,img_url=img_url,bread=bread,bcomment=bcomment,publishs_id=publishs_id)

    author = await Author.filter(id__in=authors_id)
    edit_book = await Book.get(id=book_id)
    await edit_book.authors.clear()
    await edit_book.authors.add(*author)

    return {'code': 200, 'message': "修改成功", 'data': book}

# 删除一个
@api_book.delete("/{book_id}")
async def delete_book(book_id: int):
    deleted_count = await Book.filter(id=book_id).delete()  # 条件删除
    if not deleted_count:
        return {'code': 500, 'message': "删除失败"}
    return {'code': 200, 'message': "删除成功"}