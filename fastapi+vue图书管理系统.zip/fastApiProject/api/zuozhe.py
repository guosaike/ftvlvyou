from fastapi.exceptions import HTTPException

from models import *

from fastapi import Request

# 这里是类似于 drf 的字段校验
from pydantic import BaseModel
from typing import List, Union
# 类似于django里的 path
from fastapi import APIRouter
# 生成路由对象
api_zz = APIRouter()


# 查所有
@api_zz.get("/")
async def getAllAuthor(request: Request):

    # 拿到前端传递的分页参数
    pageNum = int(request.query_params.get('pageNum', ''))
    pageSize = int(request.query_params.get('pageSize', ''))

    # 过滤
    search_nick_term = request.query_params.get('name', '')
    if search_nick_term:
        search_nick_term = search_nick_term.strip()
        Authors_sousuo = Author.filter(name__icontains=search_nick_term)
    else:
        # 拿到所有学生信息
        Authors_sousuo = Author.all()

    # 分页
    page_obj_zs = await Authors_sousuo.all().count()
    pianyi = (pageNum - 1) * pageSize  # 计算偏移量
    Authors = Authors_sousuo.limit(pageSize).offset(pianyi)

    Authors = await Authors.all().values("id","name","age")

    return {'code': 200, 'zs': page_obj_zs, 'data': Authors}


class AuthorModel(BaseModel):
    title: str
    price: int
    img_url: str
    bread: int
    clas_id: Union[int, None] = None
    authors: List[int] = []

# 增加
@api_zz.post("/")
async def addAuthor(request: Request):
    # 添加数据库操作
    # 方式1
    # Author = Author(name=stu.name, pwd=stu.pwd, sno=stu.sno, clas_id=stu.clas)
    # await Author.save()
    # 方式2
    # 拿到前端传递的图书
    json_data = await request.json()
    name = json_data["name"]
    age = json_data["age"]

    # 方式2
    author = await Author.create(name=name, age=age)

    return {'code': 200, 'message': "增加成功", 'data': author}

# 查看一个
@api_zz.get("/{Author_id}")
async def update_Author(Author_id: int):
    author = await Author.get(id=Author_id).values("id","name","age")
    return author

# 修改一个
@api_zz.put("/{Author_id}")
async def update_Author(Author_id: int, request: Request):
    # 拿到前端传递的图书
    json_data = await request.json()
    name = json_data["name"]
    age = json_data["age"]
    await Author.filter(id=Author_id).update(name=name, age=age)
    return {'code': 200, 'message': "修改成功"}

# 删除一个
@api_zz.delete("/{Author_id}")
async def delete_Author(Author_id: int):
    deleted_count = await Author.filter(id=Author_id).delete()  # 条件删除
    if not deleted_count:
        return {'code': 500, 'message': "删除失败"}
    return {'code': 200, 'message': "删除成功"}