from fastapi.exceptions import HTTPException
from models import *
# 这里是类似于 drf 的字段校验
from pydantic import BaseModel
from typing import List, Union
# 类似于django里的 path
from fastapi import APIRouter
# 生成路由对象
api_cbs = APIRouter()

from fastapi import Request


# 查所有
@api_cbs.get("/")
async def getAllPublish(request: Request):

    # 拿到前端传递的分页参数
    pageNum = int(request.query_params.get('pageNum', ''))
    pageSize = int(request.query_params.get('pageSize', ''))

    # 过滤
    search_nick_term = request.query_params.get('name', '')
    if search_nick_term:
        search_nick_term = search_nick_term.strip()
        Publishs_sousuo = Publish.filter(name__icontains=search_nick_term)
    else:
        # 拿到所有学生信息
        Publishs_sousuo = Publish.all()

    # 分页
    page_obj_zs = await Publishs_sousuo.all().count()
    pianyi = (pageNum - 1) * pageSize  # 计算偏移量
    Publishs = Publishs_sousuo.limit(pageSize).offset(pianyi)

    Publishs = await Publishs.all().values("id","name","email")

    return {'code': 200, 'zs': page_obj_zs, 'data': Publishs}


# class PublishModel(BaseModel):
#     title: str
#     price: int
#     img_url: str
#     bread: int
#     clas_id: Union[int, None] = None
#     authors: List[int] = []

# 增加
@api_cbs.post("/")
async def addPublish(request: Request):
    # 添加数据库操作
    # 方式1
    # Publish = Publish(name=stu.name, pwd=stu.pwd, sno=stu.sno, clas_id=stu.clas)
    # await Publish.save()

    # 拿到前端传递的图书
    json_data = await request.json()
    name = json_data["name"]
    email = json_data["email"]

    # 方式2
    publish = await Publish.create(name=name,email=email)

    return {'code': 200, 'message': "增加成功", 'data': publish}

# 查看一个
@api_cbs.get("/{Publish_id}")
async def update_Publish(Publish_id: int):
    publish = await Publish.get(id=Publish_id).values("id","name","email")
    return publish

# 修改一个
@api_cbs.put("/{Publish_id}")
async def update_Publish(Publish_id: int,request: Request):
    # 拿到前端传递的图书
    json_data = await request.json()
    name = json_data["name"]
    email = json_data["email"]
    await Publish.filter(id=Publish_id).update(name=name,email=email)
    return {'code': 200, 'message': "修改成功"}

# 删除一个
@api_cbs.delete("/{Publish_id}")
async def delete_Publish(Publish_id: int):
    deleted_count = await Publish.filter(id=Publish_id).delete()  # 条件删除
    if not deleted_count:
        return {'code': 500, 'message': "删除失败"}
    return {'code': 200, 'message': "删除成功"}