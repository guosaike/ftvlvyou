from tortoise.models import Model
from tortoise import fields

class Guanli(Model):
    username = fields.CharField(max_length=255)
    password = fields.CharField(max_length=255)

class Chushou(Model):
    # 姓名
    username = fields.CharField(max_length=255,null=True,blank=True,unique=True)
    # 密码
    password = fields.CharField(max_length=255,null=True,blank=True)
    img_url = fields.CharField(max_length=255, null=True, blank=True)
    # 简介
    jianjie = fields.CharField(max_length=255, default='房东', null=True, blank=True)
    shouji = fields.CharField(max_length=255, default='18888888888')

# 家长
class Goumai(Model):
    # 姓名
    username = fields.CharField(max_length=255,null=True,blank=True,unique=True)
    # 密码
    password = fields.CharField(max_length=255,null=True,blank=True)
    img_url = fields.CharField(max_length=255, null=True, blank=True)
    # 简介
    jianjie = fields.CharField(max_length=255,default='租客',null=True,blank=True)
    shouji = fields.CharField(max_length=255, default='16666666666')

class Publish(Model):
    name = fields.CharField(max_length=32, verbose_name="出版社名称")
    email = fields.CharField(max_length=32,verbose_name="出版社邮箱")

class Author(Model):
    name = fields.CharField(max_length=32, verbose_name="作者")
    age = fields.IntField(verbose_name="年龄")

class Book(Model):
    title = fields.CharField(max_length=32, verbose_name="书籍名称")
    price = fields.IntField(verbose_name="价格")
    # pub_date = models.DateField(verbose_name="出版日期")
    img_url = fields.CharField(max_length=255, null=True,blank=True,verbose_name="")
    bread = fields.IntField(verbose_name="阅读量")
    bcomment = fields.IntField(verbose_name="评论量")
    publishs = fields.ForeignKeyField('models.Publish', related_name='books')
    authors = fields.ManyToManyField('models.Author', related_name='books', description="作者")




class Clas(Model):
    name = fields.CharField(max_length=255, description='班级名称')


class Teacher(Model):
    id = fields.IntField(pk=True)
    name = fields.CharField(max_length=255, description='姓名')
    tno = fields.IntField(description='账号')
    pwd = fields.CharField(max_length=255, description='密码')


class Student(Model):
    id = fields.IntField(pk=True)
    sno = fields.IntField(description='学号')
    pwd = fields.CharField(max_length=255, description='密码')
    name = fields.CharField(max_length=255, description='姓名')
    # 一对多
    clas = fields.ForeignKeyField('models.Clas', related_name='students')
    # 多对多
    courses = fields.ManyToManyField('models.Course', related_name='students',description='学生选课表')


class Course(Model):
    id = fields.IntField(pk=True)
    name = fields.CharField(max_length=255, description='课程名')
    teacher = fields.ForeignKeyField('models.Teacher', related_name='courses', description='课程讲师')

