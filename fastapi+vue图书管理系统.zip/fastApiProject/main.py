from tortoise.contrib.fastapi import register_tortoise
from fastapi.middleware.cors import CORSMiddleware
from settings import TORTOISE_ORM,SECRET_KEY,MEDIA_ROOT
from fastapi.staticfiles import StaticFiles
from fastapi import FastAPI
from fastapi import Request, Response, status,UploadFile,File
from models import *
import uvicorn
import datetime
import jwt
import os

# 导入子路由
from api.book import api_book
from api.cbs import api_cbs
from api.zuozhe import api_zz

app = FastAPI()

# 设置静态文件路由
app.mount("/upimg", StaticFiles(directory="upimg"), name="upimg")

# origins = [
#     "http://localhost:63342"
# ]

app.add_middleware(
    CORSMiddleware,
    # allow_origins=origins,  # *：代表所有客户端
    allow_origins=["*"],  # *：代表所有客户端
    allow_credentials=True,
    # allow_methods=["GET"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_book,prefix="/ts",tags=["books图书增删改查系列接口"])
app.include_router(api_cbs,prefix="/cbs",tags=["publish出版社增删改查系列接口"])
app.include_router(api_zz,prefix="/zz",tags=["author作者增删改查系列接口"])

register_tortoise(
    app=app,
    config=TORTOISE_ORM,
)

# 前台返回格式
ret = {
    "data": {},
    "meta": {
        "status": 200,
        "message": "注册成功"
    }
}

@app.get("/")
async def root():
    return {"message": "Hello B站程序员科科"}

# 上传图片
@app.post("/img_upload")
async def img_upload(file: UploadFile = File(...)):
    contents = await file.read()
    response = {}

    # 构造图片保存路径 路径为<USER_AVATAR_ROOT + 文件名>
    # USER_AVATAR_ROOT刚刚在settings.py中规定过，需要导入进来
    # file_path = os.path.join(MEDIA_ROOT, file.filename)
    # 保存图片
    with open("./upimg/%s"%file.filename, 'wb+') as f:
        f.write(contents)
        f.close()
    response['file'] = file.filename  # 返回新的文件名
    response['code'] = 0
    response['msg'] = "图片上传成功！"
    return {'code': 200, 'message': '上传成功', 'data': response}


# 注册接口
@app.post("/register")
async def register(request: Request):
    json_data = await request.json()
    username = json_data["username"]
    password = json_data["password"]
    value = json_data["value"]

    if value == '1':
        pass
    elif value == '2':
        user = await Chushou.filter(username=username, password=password)
        if len(user) != 0:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "该商家已注册"
            return ret
        user = await Chushou.create(username=username, password=password)
        return ret
    else:
        user = await Goumai.filter(username=username, password=password)
        if len(user) != 0:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "该用户已注册"
            return ret
        user = await Goumai.create(username=username, password=password)
        return ret
    return {"message": "register"}

# 登录接口
@app.post("/login")
async def register(request: Request):
    json_data = await request.json()
    username = json_data["username"]
    password = json_data["password"]
    value = int(json_data["value"])

    if value == 1:
        user = await Guanli.get(username=username, password=password)
        if not user:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "用户不存在或密码错误"
            return ret
        elif user and user.password:
            dict = {
                "exp": datetime.datetime.now() + datetime.timedelta(days=1),  # 过期时间
                "iat": datetime.datetime.now(),  # 开始时间
                "id": user.id,
                "username": user.username,
            }
            token = jwt.encode(dict, SECRET_KEY, algorithm="HS256")
            ret["data"]["token"] = token
            ret["data"]["username"] = user.username
            ret["data"]["user_id"] = user.id
            # 这里需要根据数据库判断是不是管理员
            ret["data"]["isAdmin"] = 1
            ret["meta"]["status"] = 200
            ret["meta"]["message"] = "登录成功"
            print(ret, type(ret))
            return ret
        else:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "用户不存在或密码错误"
            return ret
    elif value == 2:
        user = await Chushou.get(username=username, password=password)
        if not user:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "用户不存在或密码错误"
            return ret
        elif user and user.password:
            dict = {
                "exp": datetime.datetime.now() + datetime.timedelta(days=1),  # 过期时间
                "iat": datetime.datetime.now(),  # 开始时间
                "id": user.id,
                "username": user.username,
            }
            token = jwt.encode(dict, SECRET_KEY, algorithm="HS256")
            ret["data"]["token"] = token
            ret["data"]["username"] = user.username
            ret["data"]["user_id"] = user.id
            # 这里需要根据数据库判断是不是管理员
            ret["data"]["isAdmin"] = 2
            ret["meta"]["status"] = 200
            ret["meta"]["message"] = "登录成功"
            print(ret, type(ret))
            return ret
        else:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "用户不存在或密码错误"
            return ret
    else:
        user = await Goumai.get(username=username, password=password)
        if not user:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "用户不存在或密码错误"
            return ret
        elif user and user.password:
            dict = {
                "exp": datetime.datetime.now() + datetime.timedelta(days=1),  # 过期时间
                "iat": datetime.datetime.now(),  # 开始时间
                "id": user.id,
                "username": user.username,
            }
            token = jwt.encode(dict, SECRET_KEY, algorithm="HS256")
            ret["data"]["token"] = token
            ret["data"]["username"] = user.username
            ret["data"]["jianjie"] = user.jianjie
            ret["data"]["img_url"] = user.img_url
            ret["data"]["user_id"] = user.id
            # 这里需要根据数据库判断是不是管理员
            ret["data"]["isAdmin"] = 3
            ret["meta"]["status"] = 200
            ret["meta"]["message"] = "登录成功"
            print(ret, type(ret))
            return ret
        else:
            ret["meta"]["status"] = 500
            ret["meta"]["message"] = "用户不存在或密码错误"
            return ret

if __name__ == '__main__':
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True,workers=1)