from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        CREATE TABLE IF NOT EXISTS `book` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `title` VARCHAR(32) NOT NULL,
    `price` INT NOT NULL,
    `img_url` VARCHAR(255),
    `bread` INT NOT NULL,
    `bcomment` INT NOT NULL,
    `publishs_id` INT NOT NULL,
    CONSTRAINT `fk_book_publish_8999eb74` FOREIGN KEY (`publishs_id`) REFERENCES `publish` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4;
        CREATE TABLE `book_author` (
    `author_id` INT NOT NULL REFERENCES `author` (`id`) ON DELETE CASCADE,
    `book_id` INT NOT NULL REFERENCES `book` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COMMENT='作者';"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        DROP TABLE IF EXISTS `book_author`;
        DROP TABLE IF EXISTS `book`;"""
