<script setup>
</script>

<template>
  <RouterView />
</template>

<style scoped>
</style>
